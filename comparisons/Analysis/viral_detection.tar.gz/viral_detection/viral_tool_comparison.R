library(tidyverse)
library(reshape2)

perform <- read_tsv(file = '~/Desktop/tool_comparison/viral_detection/performancelogs/008v_spades_kraken_performance', col_names = TRUE)

one_condition <- perform %>% filter(Filename=='008v_spades.comp')
one_filt <- one_condition %>% select(contains('F1'), contains('SSV'), contains('PPV'))
one_filt <- one_filt %>% select(contains('Phylum'), contains('Class'), contains('Order'), contains('Family'), contains('Genus'), contains('Species'))

one_melt <- melt(one_filt)


one_melt$Rank <- c('Phylum','Phylum','Phylum','Class','Class','Class','Order','Order','Order','Family','Family','Family','Genus','Genus','Genus','Species','Species','Species')
one_melt$variable <- c('F1 score','Sensitivity','PPV','F1 score','Sensitivity','PPV','F1 score','Sensitivity','PPV','F1 score','Sensitivity','PPV','F1 score','Sensitivity','PPV','F1 score','Sensitivity','PPV')
one_melt$Rank <- factor(one_melt$Rank, levels=c('Phylum','Class','Order','Family','Genus','Species'))



ggplot(data=one_melt) +
  geom_bar(aes(x=variable, y=value, fill=Rank), position = position_dodge(width=0.935), stat='identity') +
  labs(title="008v Performance - Spades & Kraken",
       subtitle='No contig length threshold - No read assignment threshold') +
  theme(axis.text.x=element_text(size=12), axis.text.y=element_text(size=12),
        plot.subtitle=element_text(hjust=0.5),
        axis.title.y=element_blank(), axis.title.x=element_blank(), plot.title=element_text(hjust=0.5))

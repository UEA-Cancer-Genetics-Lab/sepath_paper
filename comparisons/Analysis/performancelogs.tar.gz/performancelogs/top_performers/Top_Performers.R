#script to plot top performers

library(cowplot)
library(tidyverse)
library(ggpubr)
library(reshape2)

#### Top bacterial performers ####
kaiju <- read_tsv(file='~/Desktop/tool_comparison/performancelogs/top_performers/kaiju_greedy_500thresh_performance', col_names=TRUE)
kraken <- read_tsv(file='~/Desktop/tool_comparison/performancelogs/top_performers/kraken_500filt_performance', col_names=TRUE)
metaphlan <- read_tsv(file='~/Desktop/tool_comparison/performancelogs/top_performers/mph_500f_performance', col_names=TRUE)
centrifuge <- read_tsv(file='~/Desktop/tool_comparison/performancelogs/top_performers/centrifuge_200f', col_names=TRUE)
motu <- read_tsv(file='~/Desktop/tool_comparison/performancelogs/top_performers/motus_unfilt_performance', col_names=TRUE)
gottcha <- read_tsv(file='~/Desktop/tool_comparison/performancelogs/top_performers/gottcha_performance', col_names=TRUE)

kaiju_g <- kaiju %>% select(Genus_F1, Genus_PPV, Genus_SSV, Genus_TP, Genus_FP, Genus_FN)
kraken_g <- kraken %>% select(Genus_F1, Genus_PPV, Genus_SSV, Genus_TP, Genus_FP, Genus_FN)
metaphlan_g <- metaphlan %>% select(Genus_F1, Genus_PPV, Genus_SSV, Genus_TP, Genus_FP, Genus_FN)
centrifuge_g <- centrifuge %>% select(Genus_F1, Genus_PPV, Genus_SSV, Genus_TP, Genus_FP, Genus_FN)
motu_g <- motu %>% select(Genus_F1, Genus_PPV, Genus_SSV, Genus_TP, Genus_FP, Genus_FN)
gottcha_g <- gottcha %>% select(Genus_F1, Genus_PPV, Genus_SSV, Genus_TP, Genus_FP, Genus_FN)

kaiju_g$Tool = 'Kaiju'
kraken_g$Tool = 'Kraken'
metaphlan_g$Tool = 'MetaPhlAn2'
centrifuge_g$Tool = 'Centrifuge'
motu_g$Tool = 'mOTUs2'
gottcha_g$Tool = 'Gottcha'


merged <- rbind(kaiju_g, kraken_g, metaphlan_g, centrifuge_g, motu_g, gottcha_g)


#F1
F1.plot <- ggplot(merged, aes(x=Tool, y=Genus_F1, fill=Tool)) +
  geom_violin(alpha=0.8)+
  theme_pubclean() +
  labs(y='Genus F1-Score') +
  theme(axis.title.x = element_blank(),
        axis.text.x = element_text(size=12, face='bold', angle=90),
        axis.text.y = element_text(size=12),
        axis.title.y=element_text(size=12, face='bold', angle=90)) +
  guides(fill=FALSE) +
  scale_y_continuous(breaks=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1)) +
  scale_x_discrete(limits=c('mOTUs2','Kraken','MetaPhlAn2','Kaiju','Gottcha','Centrifuge')) +
  scale_fill_manual(limits=c('mOTUs2','Kraken','MetaPhlAn2','Kaiju','Gottcha','Centrifuge'),
                   values=c('darkgoldenrod2','chartreuse4','deepskyblue3','darkorchid','chocolate','darkred'))

#PPV
PPV.plot <- ggplot(merged, aes(x=Tool, y=Genus_PPV, fill=Tool)) +
  geom_violin(alpha=0.8) +
  theme_pubclean() +
  labs(y='Genus PPV') +
  theme(axis.title.x = element_blank(),
        axis.text.x = element_text(size=12, face='bold', angle=90),
        axis.text.y = element_text(size=12),
        axis.title.y=element_text(size=12, face='bold')) +
  guides(fill=FALSE) +
  scale_y_continuous(breaks=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1)) +
  scale_x_discrete(limits=c('mOTUs2','Kraken','MetaPhlAn2','Kaiju','Gottcha','Centrifuge')) +
  scale_fill_manual(limits=c('mOTUs2','Kraken','MetaPhlAn2','Kaiju','Gottcha','Centrifuge'),
                    values=c('darkgoldenrod2','chartreuse4','deepskyblue3','darkorchid','chocolate','darkred'))

#SSV
SSV.plot <- ggplot(merged, aes(x=Tool, y=Genus_SSV, fill=Tool)) +
  geom_violin(alpha=0.8) +
  theme_pubclean() +
  labs(y='Genus Sensitivity') +
  theme(axis.title.x = element_blank(),
        axis.text.x = element_text(size=12, face='bold', angle=90),
        axis.text.y = element_text(size=12),
        axis.title.y=element_text(size=12, face='bold')) +
  guides(fill=FALSE) +
  scale_y_continuous(breaks=c(0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1)) +
  scale_x_discrete(limits=c('mOTUs2','Kraken','MetaPhlAn2','Kaiju','Gottcha','Centrifuge')) +
  scale_fill_manual(limits=c('mOTUs2','Kraken','MetaPhlAn2','Kaiju','Gottcha','Centrifuge'),
                    values=c('darkgoldenrod2','chartreuse4','deepskyblue3','darkorchid','chocolate','darkred'))





#data collected from paired end kraken analysis (LSF report log of successful jobs)
#memory measured in MB, CPU_Time in seconds
kraken_computation <- data.frame(Memory=c(256192, 256191, 256191, 256192, 256191, 256192, 256192, 255612, 256193, 256195, 256192, 256192, 256192, 256193, 256192, 254960, 256192, 256190, 256192, 256192, 256192, 256194, 256192, 256188, 256194, 256192, 256192, 256192, 256194, 256193, 256194, 163004, 256192, 256191, 256191, 256191, 256192, 256191, 256192, 256192, 256191, 256191, 149473, 256191, 256191, 256192, 256192, 256191, 256194, 256191, 256193, 256192, 256195, 256197, 256193, 256193, 256193, 256193, 256193, 256193, 256195, 256193, 256193, 256194, 211494, 256193, 256193, 256193, 256193, 256193, 256193, 220723, 256192, 256193, 256193, 256193, 256193, 256193, 256193, 226081, 256193, 256193, 256192, 256199, 256195, 256193, 256193, 256193, 256194, 256193, 256193, 256193, 256192, 224880, 256195, 256191, 256193, 256194, 256193, 256193),
                                 CPU_Time =c(5380.00, 4120.23, 4174.06, 1906.39, 4302.36, 4705.00, 5621.00, 497.33, 2029.00, 1666.68, 5544.00, 1033.44, 1416.00, 2733.00, 6771.00, 4066.02, 6359.00, 4208.91, 4923.00, 6069.00, 4989.00, 1641.85, 4974.00, 6636.00, 6812.00, 5828.60, 5641.56, 5385.82, 5522.00, 4585.54, 7648.00, 394.91, 2681.36, 2483.00, 1252.28, 682.44, 3987.00, 872.01, 2512.00, 1008.15, 653.42, 1031.05, 276.49, 1683.92, 810.56, 2230.00, 4725.00, 3232.00, 2227.00, 2207.00, 2033.00, 2340.48, 5606.00, 2968.00, 543.16, 1217.52, 1265.63, 1107.57, 1007.51, 1068.19, 3939.00, 967.70, 2048.90, 628.21, 308.43, 1529.74, 2659.00, 3620.00, 2122.85, 3611.00, 2158.00, 327.35, 1576.50, 1554.97, 2291.00, 864.09, 1548.23, 2962.00, 2581.00, 372.18, 1204.53, 1575.18, 2608.00, 2928.00, 3266.00, 1573.22, 1534.72, 785.48, 2896.00, 585.15, 993.65, 1578.88, 842.42, 367.29, 1906.00, 1501.64, 1598.00, 2595.00, 1193.45, 2242.00),
                                 Max_Threads = c(20, 20, 20, 20, 20, 20, 20, 14, 20, 20, 20, 20, 20, 20, 20, 17, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 14, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 14, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 14, 20, 20, 20, 20, 20, 20, 14, 20, 20, 20, 20, 20, 20, 20, 14, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 14, 20, 20, 20, 20, 20, 20)
)


motu_computation <- data.frame(Memory=c(2295, 1799, 1864, 2197, 1736, 1906, 2263, 1567, 2065, 2961, 2263, 1767, 1808, 2199, 2337, 1623, 2241, 1576, 2056, 2454, 1860, 2066, 1910, 1969, 3213, 2008, 1798, 1847, 1763, 1536, 2349, 1485, 2323, 3101, 2162, 1681, 3169, 1742, 2364, 1856, 1773, 1794, 1605, 2073, 1783, 2438, 3152, 2493, 2290, 2316, 2517, 2390, 1733, 2718, 1665, 1983, 1968, 1841, 1786, 1878, 2701, 1793, 2291, 1855, 1602, 1748, 2283, 2765, 2901, 3014, 1975, 1611, 2058, 2415, 2224, 1817, 2057, 3633, 2427, 1596, 1915, 2120, 2400, 2540, 2928, 2820, 1947, 1848, 2728, 1703, 1955, 2024, 1842, 1654, 2633, 1877, 2223, 2522, 1976, 2439),
                               CPU_Time = c(5374.40, 2273.08, 2495.20, 4491.53, 2517.45, 2752.51, 4556.09, 1204.01, 4858.34, 4137.60, 4613.32, 2855.05, 2296.37, 6466.51, 6439.86, 1294.92, 6087.35, 720.51, 2250.50, 5881.19, 2241.79, 4022.73, 2164.46, 6357.76, 5583.45, 3809.04, 2260.66, 2887.39, 1881.59, 1160.46, 7085.49, 460.19, 6440.59, 5958.31, 2319.85, 1957.41, 8362.51, 1355.26, 4456.02, 2691.23, 1001.10, 1720.56, 1087.89, 3256.38, 2247.44, 4523.00, 11285.98, 7613.48, 5250.01, 5188.79, 5036.01, 5780.81, 1654.05, 6662.63, 1676.76, 3265.09, 2317.76, 2894.40, 2752.37, 1844.36, 8108.55, 2656.75, 4980.62, 1873.16, 1107.45, 3769.75, 5341.07, 7960.86, 5448.30, 7836.13, 5204.30, 1142.85, 4363.06, 2949.02, 5399.71, 2261.21, 2910.79, 6321.63, 6017.40, 1257.97, 2281.32, 3926.57, 5967.97, 7032.43, 7643.20, 3038.37, 3068.73, 2219.21, 5329.26, 767.40, 2751.40, 2648.04, 1428.02, 1234.83, 4465.87, 3609.81, 2959.40, 5767.98, 2902.22, 5436.18),
                               Max_Threads=c(17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17)
)

kraken_computation$Tool = 'Kraken'
motu_computation$Tool= 'mOTUs2'

merged_computation <- rbind(kraken_computation, motu_computation)

merged_computation <- merged_computation %>% select(Memory, CPU_Time, Tool)
#change to GB RAM
merged_computation <- merged_computation %>% mutate(Memory = Memory / 1000)

computation_melt <- melt(merged_computation)


#plot GB RAM
memory <- ggplot(merged_computation, aes(x=Tool, y=Memory)) +
  geom_boxplot(aes(fill=Tool)) +
  theme_pubclean() +
  guides(fill=FALSE) +
  labs(title='',
       y='Maximum RAM (GB)') +
  theme(plot.title=element_text(size=16, hjust=0.5, face='bold'),
        axis.title.x=element_blank(),
        axis.text.x=element_text(size=12, face='bold', angle=90),
        axis.text.y = element_text(size=12),
        axis.title.y=element_text(size=12, face='bold')) +
  scale_y_continuous(breaks=c(2,100,200,256)) +
  scale_fill_manual(limits=c('mOTUs2','Kraken'),
                    values=c('darkgoldenrod2','chartreuse4'))
  


#plot CPU_Time
cpu_time <- ggplot(merged_computation, aes(x=Tool, y=CPU_Time)) +
  geom_boxplot(aes(fill=Tool)) +
  theme_pubclean() +
  guides(fill=FALSE) +
  labs(title='',
       y='CPU Time (seconds)') +
  theme(plot.title=element_text(size=12, hjust=0.5, face='bold'),
        axis.title.x=element_blank(),
        axis.text.x=element_text(size=12, face='bold', angle=90),
        axis.text.y = element_text(size=12),
        axis.title.y=element_text(size=12, face='bold')) +
  scale_y_continuous(breaks=c(0,1000, 2140,3162, 4000, 5000, 6000, 7000, 8000, 9000, 10000,11000,12000)) +
  scale_fill_manual(limits=c('mOTUs2','Kraken'),
                    values=c('darkgoldenrod2','chartreuse4'))


resources.plot <- ggarrange(cpu_time, memory, ncol=2, nrow=1)

#cow plot to arrange plots nicely
pdf('Tool_Comparison', width=9, height=9)
plot_grid(SSV.plot, PPV.plot, F1.plot, resources.plot,  labels=c('A', 'B','C','D'))
dev.off()





####Assembly performance with no filter####
spades_krak <- read_tsv(file='~/Desktop/tool_comparison/performancelogs/top_performers/spades_krak_unfilt_performance', col_names=TRUE)
spades_g <- spades_krak %>% select(Genus_F1, Genus_PPV, Genus_SSV)
#spades_melt <- melt(spades_g)

spades_krak_filt <- read_tsv(file='~/Desktop/tool_comparison/performancelogs/top_performers/spades_krak_unfilt_4thresh_performance', col_names=TRUE)
spades_g_filt <- spades_krak_filt %>% select(Genus_F1, Genus_PPV, Genus_SSV)
#spades_melt_filt <- melt(spades_g_filt)

spades_g_filt$Threshold = 'Yes'
spades_g$Threshold = 'No'

spades_gF1 <- spades_g %>% select(Genus_F1, Threshold)
spades_gssv <- spades_g %>% select(Genus_SSV, Threshold)
spades_gppv <- spades_g %>% select(Genus_PPV, Threshold)
spades_g_filt_F1 <- spades_g_filt %>% select(Genus_F1, Threshold)
spades_g_filt_ssv <- spades_g_filt %>% select(Genus_SSV, Threshold)
spades_g_filt_ppv <- spades_g_filt %>% select(Genus_PPV, Threshold)
spadesF1 <- rbind(spades_gF1, spades_g_filt_F1)
spadesssv <-rbind(spades_gssv, spades_g_filt_ssv)
spadesppv <-rbind(spades_gppv, spades_g_filt_ppv)
  

#spades_melt_merge <- rbind(spades_melt, spades_melt_filt)
spadesf1.plot <-ggplot(spadesF1, aes(y=Genus_F1, x=Threshold, fill=Threshold)) +
  geom_violin(alpha=0.8) +
  theme_pubclean() +
  scale_y_continuous(breaks=seq(0,1,0.1),
                     limits=c(0,1)) +
  scale_fill_manual(limits=c('No', 'Yes'),
                 values=c('navy','mediumaquamarine'),
                 guide=FALSE) +
  labs(title='Genus F1-Score',
       y='Genus F1-Score') +
  theme(plot.title=element_text(size=12, hjust=0.5, face='bold'),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y = element_text(size=12),
        axis.title.y=element_text(size=12, face='bold'),
        axis.ticks.x=element_blank())

  

spadesssv.plot <-ggplot(spadesssv, aes(y=Genus_SSV, x=Threshold, fill=Threshold)) +
  geom_violin() +
  theme_pubclean() +
  scale_y_continuous(breaks=seq(0,1,0.1),
                     limits=c(0,1)) +
  scale_fill_manual(limits=c('No', 'Yes'),
                    values=c('navy','mediumaquamarine'),
                    guide=FALSE) +
  labs(title='Genus Sensitivity',
       y='Genus Sensitivity') +
  theme(plot.title=element_text(size=12, hjust=0.5, face='bold'),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y = element_text(size=12),
        axis.title.y=element_text(size=12, face='bold'),
        axis.ticks.x=element_blank())

spadesppv.plot <-ggplot(spadesppv, aes(y=Genus_PPV, x=Threshold, fill=Threshold)) +
  geom_violin() +
  theme_pubclean() +
  scale_y_continuous(breaks=seq(0,1,0.1),
                     limits=c(0,1)) +
  scale_fill_manual(name='Threshold:',
                    limits=c('No', 'Yes'),
                    values=c('navy','mediumaquamarine'),
                    labels=c('Unfiltered','>4 Contigs'),
                    guide=FALSE) +
  labs(title='Genus PPV',
       y='Genus PPV') +
  theme(plot.title=element_text(size=12, hjust=0.5, face='bold'),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y = element_text(size=12),
        axis.title.y=element_text(size=12, face='bold'),
        axis.ticks.x=element_blank()) +
  guides(position='right')


#empty plot - just used for legend harvesting
leg <- ggplot(spadesppv, aes(y=Genus_PPV, x=Threshold, fill=Threshold)) +
  geom_violin() +
  scale_y_continuous(breaks=seq(0,1,0.1)) +
  scale_fill_manual(name='Threshold:',
                    limits=c('No', 'Yes'),
                    values=c('navy','mediumaquamarine'),
                    labels=c('Unfiltered','>4 Contigs'),
                    position='right') +
  theme(plot.title=element_blank(),
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.text.y = element_blank(),
        axis.title.y=element_blank())
leg_plot <- as_ggplot(get_legend(leg))



#cow plot to arrange plots nicely
pdf('Contig_Performance', width=9, height=9)
plot_grid(spadesf1.plot, spadesssv.plot, spadesppv.plot, leg_plot, labels=c('A', 'B','C', NULL))
dev.off()






these files are contigs filtered for a minimum of 100 assigned reads, 100 kmers and 0.01coverage

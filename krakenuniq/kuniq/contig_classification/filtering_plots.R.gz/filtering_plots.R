library(tidyverse)
library(ggpubr)
library(cowplot)

kraken002 <- read_tsv(file='~/Desktop/tool_comparison/kuniq/contig_classification/002.report', col_names=TRUE, skip=2)
kraken002 <- kraken001 %>% filter(rank=='genus')
true_genus <- c('Abiotrophia', 'Actinobaculum', 'Actinomyces', 'Actinotignum', 'Anaerococcus', 'Bacteroides', 'Blautia', 'Bulleidia', 'Campylobacter', 'Catonella', 'Corynebacterium', 'Cutibacterium', 'Dialister', 'Enterococcus', 'Fusobacterium', 'Gemella', 'Genus', 'Haemophilus', 'Helicobacter', 'Holdemania', 'Kingella', 'Leptotrichia', 'Listeria', 'Mannheimia', 'Mobiluncus', 'Moraxella', 'Mycoplasma', 'Neisseria', 'Pasteurella', 'Peptoniphilus', 'Porphyromonas', 'Prevotella', 'Propionibacteriaceae', 'Propionimicrobium', 'Rothia', 'Salmonella', 'Sneathia', 'Staphylococcus', 'Streptobacillus', 'Streptococcus', 'Treponema', 'Ureaplasma', 'Veillonella')

kraken002$found <- ifelse(kraken002$taxName %in% true_genus, 'Found', 'Not_Found')


reads.plot <- ggplot(data=kraken002, aes(x=log(reads), fill=found)) +
                  geom_histogram(alpha=0.7) +
                  theme_pubclean() +
                  labs(title='Taxon Reads vs Classification Accuracy',
                       y='Density',
                       x='Log Number of Taxon Reads') +
                  scale_fill_manual(name = 'Result',
                                      values=c('chartreuse3','firebrick'),
                                      breaks = c('Found', 'Not_Found'),
                                      labels = c('True Positive', 'False Positive'),
                                      guide=FALSE) +
                  theme(plot.title=element_text(hjust=0.5, size=14),
                        legend.position='right',
                        axis.title.y=element_text(size=14),
                        axis.title.x=element_text(size=14))


kmers.plot <- ggplot(data=kraken002, aes(x=log(kmers), fill=found)) +
  geom_histogram(alpha=0.7) +
  theme_pubclean() +
  labs(title='Unique Kmer Counts vs Classification Accuracy',
       x='Log Number of Unique Kmers') +
  scale_fill_manual(name = 'Result',
                    values=c('chartreuse3','firebrick'),
                    breaks = c('Found', 'Not_Found'),
                    labels = c('True Positive', 'False Positive'),
                    guide=FALSE) +
  theme(plot.title=element_text(hjust=0.5, size=14),
        legend.position='right',
        axis.title.y = element_blank(),
        axis.title.x=element_text(size=14))


coverage.plot <- ggplot(data=kraken002, aes(x=log(cov), fill=found)) +
  geom_histogram(alpha=0.7) +
  theme_pubclean() +
  labs(title='K-mer Coverage vs Classification Accuracy',
       x='Log k-mer Coverage of Clade in Database') +
  scale_fill_manual(name = 'Result',
                    values=c('chartreuse3','firebrick'),
                    breaks = c('Found', 'Not_Found'),
                    labels = c('True Positive', 'False Positive'),
                    guide=FALSE) +
  theme(plot.title=element_text(hjust=0.5, size=14),
        axis.title.y = element_blank(),
        axis.title.x = element_text(size=14))


legend.plot <- ggplot(data=kraken002, aes(x=log(cov), fill=found)) +
  geom_histogram(alpha=0.7) +
  theme_pubclean() +
  scale_fill_manual(name = 'Result',
                    values=c('chartreuse3','firebrick'),
                    breaks = c('Found', 'Not_Found'),
                    labels = c('True Positive', 'False Positive')) +
  theme(legend.position='left')

leg.plot <- as_ggplot(get_legend(legend.plot))


plot_grid(reads.plot, kmers.plot, coverage.plot, leg.plot, labels=c('A','B','C',NULL), align='h', ncol=4)





#!/bin/bash

#this script will remove line breaks from fasta files

cat *part-10.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_10.fasta; rm -f *part-10.fasta
cat *part-11.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_11.fasta; rm -f *part-11.fasta
cat *part-12.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_12.fasta; rm -f *part-12.fasta
cat *part-13.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_13.fasta; rm -f *part-13.fasta
cat *part-14.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_14.fasta; rm -f *part-14.fasta
cat *part-15.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_15.fasta; rm -f *part-15.fasta
cat *part-16.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_16.fasta; rm -f *part-16.fasta
cat *part-17.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_17.fasta; rm -f *part-17.fasta
cat *part-18.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_18.fasta; rm -f *part-18.fasta
cat *part-19.fasta | awk '!/^>/ { printf "%s", $0; n = "\n" } /^>/ { print n $0; n = "" } END { printf "%s", n }' > part_19.fasta; rm -f *part-19.fasta

#!/bin/bash

bsub -x -J fq_snake -q long-eth -M 60000 -R "rusage[mem=60000]" "./ouroborous.snake"

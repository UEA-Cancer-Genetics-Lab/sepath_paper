#!/gpfs/software/python/anaconda/4.2/anaconda2/bin/python

#This script will initiate file manipulation before splitting a fasta and initiating a fq generation snakemake

#call script filetoprocess

import os
import sys
import time

file = sys.argv[1]
filename = os.path.basename(file)
gzlessfile = filename[:-3]

print("processing file: %s" %file)

#copy file to current directory, gunzip and split into multiple files
os.system("cp %s ./; gunzip %s; fasta-splitter.pl --part-size 10000000 --measure count %s" %(file, filename, gzlessfile))


#remove pesky lines from each split fasta file - load 2 jobs to just speed it up a bit 
os.system('bsub -J format_splits2 -q short-ib -M 4000 -R "rusage[mem=4000]" "reformat_splits.sh"')
os.system('bsub -J format_splits2 -q short-ib -M 4000 -R "rusage[mem=4000]" "reformat_splits2.sh"')
os.system('bsub -J format_splits2 -q short-ib -M 4000 -R "rusage[mem=4000]" "reformat_splits3.sh"')

#sleep for a while to prevent jobs being launched prematurely 480 = 8 mins
time.sleep(480)

#launch snakemake to generate fastq files
os.system('./generalrunner.sh')
#os.system('module add python/anaconda/4.2/3.5; source ~/dependencies; source ~/path-maker; bsub -J fq_snake -q long-eth -M 10000 -R "rusage[mem=10000]" "snakemake --jobs 12 --cluster \"bsub -q {params.queue} {params.cluster}\" --latency-wait 1200 --timestamp"')


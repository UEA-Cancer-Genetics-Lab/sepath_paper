#!/bin/bash

bsub -q short-ib -M 60000 -R "rusage[mem=60000]" "cat *part*fastq | gzip > final.fastq.gz; rm -f part*fast*; fq_to_count.py final.fastq.gz"


#now do some cleanup and remove the parts

